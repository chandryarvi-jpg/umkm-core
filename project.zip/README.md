# UMKM-Core (Solusi Lapak Instan)

Fondasi proyek — Langkah 1 & 2 dari roadmap pengembangan.

## Langkah 1 — Setup Gradle
- `build.gradle.kts` (root) + `gradle/libs.versions.toml`: version catalog terpusat untuk
  Compose BOM, Room 2.6.1, Hilt 2.52, Coroutines 1.9.0, Retrofit, dan Kotlin Serialization.
- `app/build.gradle.kts`: minSdk 24 (menjangkau device low-end lama), Java 17, R8 aktif
  di build release untuk ukuran APK sekecil mungkin.

## Langkah 2 — Struktur MVVM Modular by Feature
```
com.umkmcore.app/
├── core/
│   ├── di/          -> Hilt modules (DatabaseModule, RepositoryModule)
│   └── util/        -> helper lintas fitur (regex, formatter, dll — diisi Langkah 3+)
├── data/
│   ├── local/
│   │   ├── entity/  -> ProductEntity, OrderEntity, CustomerEntity, ContentTemplateEntity
│   │   └── dao/     -> DAO Room untuk masing-masing entity
│   ├── remote/      -> dto/ & service/ untuk API Ongkir + sinkronisasi cloud opsional
│   └── repository/  -> implementasi konkret (Room + remote), mem-mapping Entity <-> domain Model
├── domain/
│   ├── model/       -> Product, Order, Customer, ContentTemplate (murni Kotlin, tanpa Room)
│   ├── repository/  -> kontrak interface (dipakai ViewModel, tidak tahu soal Room)
│   └── usecase/     -> business logic per aksi (diisi Langkah 3+, contoh: ExtractOrderTextUseCase)
└── ui/
    ├── theme/       -> Color, Type, Theme (Material 3, tanpa dynamic color)
    ├── navigation/  -> Destination + NavHost, satu Activity untuk semua layar
    ├── dashboard/   -> DashboardScreen + DashboardViewModel (contoh pola MVVM lengkap)
    ├── module1_resi/      -> placeholder Modul 1 (Cetak Resi)
    ├── module2_keyboard/  -> placeholder Modul 2 (Custom Sales Keyboard)
    ├── module3_hpp/       -> placeholder Modul 3 (Kalkulator HPP)
    └── module4_katalog/   -> placeholder Modul 4 (Katalog & Konten)
```

**Alur ketergantungan:** `ui -> domain <- data`. Domain tidak pernah bergantung pada Room
atau Retrofit — ini yang membuat setiap modul bisa dites dan dikembangkan terpisah.

## Cara membuka
1. Buka folder ini di Android Studio (Koala/Ladybug+).
2. Sync Gradle (semua versi sudah dikunci di `libs.versions.toml`).
3. Jalankan di device/emulator minSdk 24+.

## Langkah 3 — Modul 1: Ekstraktor Alamat & Cetak Resi
- `core/util/RegexExtractor.kt`: mesin regex 2 lapis (label eksplisit → heuristik pola)
  untuk memisahkan Nama, No HP, Alamat, dan Kurir dari teks chat mentah.
- `domain/usecase/ExtractOrderTextUseCase.kt`: pembungkus tipis agar ViewModel tidak
  bergantung langsung ke `core.util`.
- `ui/module1_resi/ThermalLabelPreview.kt`: pratinjau visual label 58mm (font monospace).
- `ui/module1_resi/BluetoothPrinterHelper.kt`: cetak nyata ke printer thermal via
  Classic Bluetooth SPP + perintah ESC/POS (init, align, bold, cut).

## Langkah 4 — Modul 3 & Dashboard Utama
- `domain/usecase/CalculateHppUseCase.kt`: formula Bahan Baku + Biaya Operasional/unit
  → HPP → Harga Jual Ideal (berbasis margin atas harga jual) → BEP (unit/bulan).
- `ui/dashboard/DashboardViewModel.kt`: orkestrator state untuk ekstraksi alamat,
  kalkulator HPP, dan simpan produk ke `ProductRepository` (Room DB).
- `ui/dashboard/DashboardScreen.kt`: satu layar Material 3 berisi paste chat + preview
  label, form kalkulator HPP, dan daftar stok — semuanya reaktif via `StateFlow`.

## Yang belum ada (menyusul di iterasi berikutnya)
- Implementasi `OrderRepository` & `ContentRepository` (baru interface) — untuk
  menyimpan histori order dan ide konten 30 hari.
- IME Service nyata untuk Custom Sales Keyboard (Modul 2) & Cek Ongkir.
- Generator Katalog Web statis (Modul 4).
- Migration Room eksplisit sebelum rilis (saat ini masih `fallbackToDestructiveMigration`).
