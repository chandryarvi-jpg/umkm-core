package com.umkmcore.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.umkmcore.app.ui.dashboard.DashboardScreen
import com.umkmcore.app.ui.module2_keyboard.SalesKeyboardScreenPlaceholder
import com.umkmcore.app.ui.module4_katalog.CatalogContentScreenPlaceholder

@Composable
fun UmkmNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Destination.Dashboard.route) {
        composable(Destination.Dashboard.route) {
            // Modul 1 (Ekstraktor Alamat + Cetak Resi) dan Modul 3 (HPP + Stok) sudah
            // menyatu langsung di dalam DashboardScreen, jadi tidak perlu rute terpisah lagi.
            DashboardScreen(
                onOpenSalesKeyboard = { navController.navigate(Destination.SalesKeyboard.route) },
                onOpenCatalogContent = { navController.navigate(Destination.CatalogContent.route) }
            )
        }
        composable(Destination.SalesKeyboard.route) { SalesKeyboardScreenPlaceholder() }
        composable(Destination.CatalogContent.route) { CatalogContentScreenPlaceholder() }
    }
}
