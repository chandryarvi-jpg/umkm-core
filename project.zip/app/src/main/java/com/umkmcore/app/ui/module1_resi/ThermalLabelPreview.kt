package com.umkmcore.app.ui.module1_resi

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.umkmcore.app.domain.model.ExtractedOrderText

/**
 * Pratinjau visual label pengiriman untuk kertas thermal 58mm.
 * Lebar 220dp dipilih untuk mensimulasikan rasio kertas 58mm secara proporsional
 * di layar HP, dengan font monospace agar hasilnya mendekati cetakan asli.
 */
private val LABEL_WIDTH = 220.dp

@Composable
fun ThermalLabelPreview(
    storeName: String,
    extracted: ExtractedOrderText,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(LABEL_WIDTH)
            .border(1.dp, Color(0xFFBDBDBD), RoundedCornerShape(2.dp))
            .background(Color.White)
            .padding(12.dp)
    ) {
        Text(
            text = storeName.ifBlank { "TOKO ANDA" }.uppercase(),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = Color.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        DashedDivider()

        LabelRow("Penerima", extracted.recipientName ?: "-")
        LabelRow("No. HP", extracted.phoneNumber ?: "-")
        LabelRow("Kurir", extracted.courierName ?: "-")

        Text(
            text = "ALAMAT:",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = Color.Black,
            modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            text = extracted.fullAddress ?: "-",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = Color.Black
        )

        DashedDivider()
        Text(
            text = "Dicetak via UMKM-Core",
            fontFamily = FontFamily.Monospace,
            fontSize = 8.sp,
            color = Color(0xFF757575),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun LabelRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "$label:",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.width(70.dp)
        )
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = Color.Black
        )
    }
}

@Composable
private fun DashedDivider() {
    Text(
        text = "------------------------------",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        color = Color(0xFF9E9E9E),
        maxLines = 1
    )
}
