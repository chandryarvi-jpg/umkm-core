package com.umkmcore.app.domain.repository

import com.umkmcore.app.domain.model.Product
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun observeProducts(): Flow<List<Product>>
    suspend fun getProduct(id: Long): Product?
    suspend fun saveProduct(product: Product): Long
    suspend fun decrementStock(productId: Long, quantity: Int)
    suspend fun getCatalogProducts(): List<Product>
}
