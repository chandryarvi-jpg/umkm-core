package com.umkmcore.app.domain.repository

import com.umkmcore.app.domain.model.BusinessCategory
import com.umkmcore.app.domain.model.ContentIdea
import com.umkmcore.app.domain.model.SalesMacro

interface ContentRepository {
    suspend fun getSalesMacros(): List<SalesMacro>
    suspend fun getContentIdeas(category: BusinessCategory): List<ContentIdea>
}
