package com.umkmcore.app.core.di

import android.content.Context
import androidx.room.Room
import com.umkmcore.app.data.local.UmkmCoreDatabase
import com.umkmcore.app.data.local.dao.ContentTemplateDao
import com.umkmcore.app.data.local.dao.CustomerDao
import com.umkmcore.app.data.local.dao.OrderDao
import com.umkmcore.app.data.local.dao.ProductDao
import com.umkmcore.app.data.local.migration.ALL_MIGRATIONS
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): UmkmCoreDatabase =
        Room.databaseBuilder(context, UmkmCoreDatabase::class.java, UmkmCoreDatabase.DATABASE_NAME)
            // Migrasi eksplisit — data stok UMKM tidak pernah terhapus otomatis saat update.
            // Setiap kenaikan `version` WAJIB disertai Migration baru di ALL_MIGRATIONS.
            .addMigrations(*ALL_MIGRATIONS)
            .build()

    @Provides
    fun provideProductDao(db: UmkmCoreDatabase): ProductDao = db.productDao()

    @Provides
    fun provideOrderDao(db: UmkmCoreDatabase): OrderDao = db.orderDao()

    @Provides
    fun provideCustomerDao(db: UmkmCoreDatabase): CustomerDao = db.customerDao()

    @Provides
    fun provideContentTemplateDao(db: UmkmCoreDatabase): ContentTemplateDao = db.contentTemplateDao()
}
