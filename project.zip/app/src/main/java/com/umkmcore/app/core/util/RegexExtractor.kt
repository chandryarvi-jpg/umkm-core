package com.umkmcore.app.core.util

import com.umkmcore.app.domain.model.ExtractedOrderText

/**
 * Mesin ekstraksi berbasis Regex ("Logika AI/Regex Ringan") untuk Modul 1.
 *
 * Strategi dua lapis untuk tiap field:
 * 1) Cari baris berlabel eksplisit (mis. "Nama:", "Alamat:", "No HP:", "Kurir:") —
 *    ini menutupi format order yang sudah terstruktur.
 * 2) Jika tidak ada label, jatuh ke heuristik pola (nomor HP via regex universal,
 *    nama kurir via daftar ekspedisi dikenal, alamat via kata kunci geografis) —
 *    ini menutupi chat mentah pelanggan yang ditulis bebas.
 *
 * Murni Kotlin, tanpa dependensi Android — bisa dites sebagai unit test biasa.
 */
object RegexExtractor {

    private val PHONE_REGEX = Regex("""(?:\+62|62|0)8[0-9]{8,12}""")

    private val NAME_LABEL_REGEX = Regex("""(?i)^\s*(nama|atas\s*nama|a\.?n\.?|penerima)\s*[:\-]\s*(.+)$""")
    private val PHONE_LABEL_REGEX = Regex("""(?i)^\s*(no\.?\s*hp|no\.?\s*telp|nomor\s*hp|whatsapp|wa|hp|telp|telepon)\s*[:\-]\s*(.+)$""")
    private val ADDRESS_LABEL_REGEX = Regex("""(?i)^\s*(alamat(\s*lengkap)?|kirim\s*ke|dikirim\s*ke)\s*[:\-]\s*(.+)$""")
    private val COURIER_LABEL_REGEX = Regex("""(?i)^\s*(kurir|ekspedisi|kirim\s*(pakai|via))\s*[:\-]\s*(.+)$""")

    private val KNOWN_COURIERS = listOf(
        "JNE", "J&T", "JNT", "SiCepat", "AnterAja", "Ninja Xpress", "Ninja Express",
        "ID Express", "IDExpress", "Lion Parcel", "Wahana", "Pos Indonesia",
        "GoSend", "Gojek", "GrabExpress", "Grab", "Paxel", "Shopee Express", "SPX"
    )

    private val ADDRESS_HINT_WORDS = listOf(
        "jl.", "jl ", "jalan", "no.", " rt ", " rw ", "rt/rw", "kel.", "kelurahan",
        "kec.", "kecamatan", "kabupaten", "kab.", "kota", "provinsi", "blok",
        "gang", "gg.", "perumahan", "komplek", "desa"
    )

    /** Titik masuk utama — dipanggil dari [com.umkmcore.app.domain.usecase.ExtractOrderTextUseCase]. */
    fun extract(rawText: String): ExtractedOrderText {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }

        val phone = extractPhone(rawText, lines)
        val courier = extractCourier(rawText, lines)
        val address = extractAddress(lines)
        val name = extractName(lines, address)

        return ExtractedOrderText(
            recipientName = name,
            phoneNumber = phone,
            fullAddress = address,
            courierName = courier,
            rawText = rawText
        )
    }

    private fun extractPhone(rawText: String, lines: List<String>): String? {
        for (line in lines) {
            val labelMatch = PHONE_LABEL_REGEX.find(line) ?: continue
            val candidate = PHONE_REGEX.find(labelMatch.groupValues.last())
            if (candidate != null) return normalizePhone(candidate.value)
        }
        // Fallback: cari pola nomor HP di mana saja dalam teks mentah.
        return PHONE_REGEX.find(rawText)?.let { normalizePhone(it.value) }
    }

    private fun normalizePhone(raw: String): String {
        var digits = raw.filter { it.isDigit() || it == '+' }
        digits = when {
            digits.startsWith("+62") -> "0" + digits.removePrefix("+62")
            digits.startsWith("62") -> "0" + digits.removePrefix("62")
            else -> digits
        }
        return digits
    }

    private fun extractCourier(rawText: String, lines: List<String>): String? {
        for (line in lines) {
            val labelMatch = COURIER_LABEL_REGEX.find(line) ?: continue
            val value = labelMatch.groupValues.last().trim()
            if (value.isNotBlank()) return value
        }
        // Fallback: cocokkan terhadap daftar nama ekspedisi yang dikenal.
        return KNOWN_COURIERS.firstOrNull { rawText.contains(it, ignoreCase = true) }
    }

    private fun extractAddress(lines: List<String>): String? {
        val labelIndex = lines.indexOfFirst { ADDRESS_LABEL_REGEX.matches(it) }
        if (labelIndex != -1) {
            val labelMatch = ADDRESS_LABEL_REGEX.find(lines[labelIndex])!!
            val builder = StringBuilder(labelMatch.groupValues.last().trim())

            // Gabungkan baris-baris lanjutan selama belum menabrak label field lain,
            // karena alamat pelanggan sering ditulis multi-baris (RT/RW di baris terpisah).
            var i = labelIndex + 1
            while (
                i < lines.size &&
                !PHONE_LABEL_REGEX.matches(lines[i]) &&
                !COURIER_LABEL_REGEX.matches(lines[i]) &&
                !NAME_LABEL_REGEX.matches(lines[i])
            ) {
                builder.append(", ").append(lines[i])
                i++
            }
            return builder.toString().trim().trimEnd(',').takeIf { it.isNotBlank() }
        }

        // Fallback heuristik: baris terpanjang yang mengandung kata kunci geografis umum.
        return lines
            .filter { line -> ADDRESS_HINT_WORDS.any { line.contains(it, ignoreCase = true) } }
            .maxByOrNull { it.length }
    }

    private fun extractName(lines: List<String>, address: String?): String? {
        for (line in lines) {
            val labelMatch = NAME_LABEL_REGEX.find(line) ?: continue
            val value = labelMatch.groupValues.last().trim()
            if (value.isNotBlank()) return value
        }

        // Fallback: baris pendek pertama yang bukan alamat, bukan nomor HP,
        // dan bukan baris label kurir — biasanya baris pembuka chat pelanggan.
        return lines.firstOrNull { line ->
            line != address &&
                !PHONE_REGEX.containsMatchIn(line) &&
                !COURIER_LABEL_REGEX.matches(line) &&
                ADDRESS_HINT_WORDS.none { line.contains(it, ignoreCase = true) } &&
                line.length in 3..40
        }
    }
}
