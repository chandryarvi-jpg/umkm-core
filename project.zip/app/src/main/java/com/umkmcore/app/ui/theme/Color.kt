package com.umkmcore.app.ui.theme

import androidx.compose.ui.graphics.Color

// Palet netral & hangat — kontras tinggi agar tetap terbaca di layar low-end/low-brightness.
val UmkmGreenPrimary = Color(0xFF2E7D5B)
val UmkmGreenPrimaryDark = Color(0xFF1B5E44)
val UmkmOrangeAccent = Color(0xFFE8833A)
val UmkmSurfaceLight = Color(0xFFFAFAF7)
val UmkmSurfaceDark = Color(0xFF1C1C1A)
val UmkmError = Color(0xFFBA1A1A)
