package com.umkmcore.app.domain.model

/** Model domain murni — tidak mengetahui apa pun soal Room/anotasi database. */
data class Product(
    val id: Long,
    val name: String,
    val sellPrice: Double,
    val hppPrice: Double,
    val stockQuantity: Int,
    val category: BusinessCategory,
    val imageUri: String?,
    val isPublishedToCatalog: Boolean
) {
    val marginPercentage: Double
        get() = if (sellPrice == 0.0) 0.0 else ((sellPrice - hppPrice) / sellPrice) * 100
}

enum class BusinessCategory { FNB, FASHION, JASA, RETAIL }

/** Label tampilan Bahasa Indonesia untuk dropdown kategori di UI. */
fun BusinessCategory.displayLabel(): String = when (this) {
    BusinessCategory.FNB -> "F&B (Makanan/Minuman)"
    BusinessCategory.FASHION -> "Fashion"
    BusinessCategory.JASA -> "Jasa"
    BusinessCategory.RETAIL -> "Retail"
}
