package com.umkmcore.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.umkmcore.app.domain.model.BusinessCategory
import com.umkmcore.app.domain.model.ExtractedOrderText
import com.umkmcore.app.domain.model.Product
import com.umkmcore.app.domain.repository.ProductRepository
import com.umkmcore.app.domain.usecase.CalculateHppUseCase
import com.umkmcore.app.domain.usecase.ExtractOrderTextUseCase
import com.umkmcore.app.domain.usecase.HppInput
import com.umkmcore.app.domain.usecase.HppResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** State untuk Modul 1: Ekstraktor Teks Alamat. */
data class AddressExtractionState(
    val rawText: String = "",
    val extracted: ExtractedOrderText? = null
)

/** State untuk Modul 3: Kalkulator HPP & Stok. Nilai numerik disimpan sebagai String
 *  agar mudah dibind ke OutlinedTextField, lalu diparse saat kalkulasi. */
data class HppCalculatorState(
    val productName: String = "",
    val category: BusinessCategory = BusinessCategory.FNB,
    val rawMaterialCost: String = "",
    val monthlyOperationalCost: String = "",
    val estimatedMonthlyProduction: String = "",
    val marginPercentage: String = "",
    val initialStock: String = "",
    val result: HppResult? = null,
    val errorMessage: String? = null
)

data class DashboardUiState(
    val isLoading: Boolean = true,
    val products: List<Product> = emptyList(),
    val lowStockProducts: List<Product> = emptyList(),
    val addressInput: AddressExtractionState = AddressExtractionState(),
    val hppCalculator: HppCalculatorState = HppCalculatorState(),
    val saveMessage: String? = null
)

/**
 * ViewModel tunggal untuk Dashboard yang menyatukan Modul 1 (ekstraksi alamat)
 * dan Modul 3 (HPP + stok), sesuai arsitektur "Dashboard minimalis" di spesifikasi.
 * Setiap modul tetap terisolasi lewat use case & repository masing-masing —
 * ViewModel ini hanya bertindak sebagai orkestrator state UI.
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val productRepository: ProductRepository,
    private val extractOrderTextUseCase: ExtractOrderTextUseCase,
    private val calculateHppUseCase: CalculateHppUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        observeProducts()
    }

    private fun observeProducts() {
        viewModelScope.launch {
            productRepository.observeProducts().collect { products ->
                _uiState.update { current ->
                    current.copy(
                        isLoading = false,
                        products = products,
                        lowStockProducts = products.filter { it.stockQuantity <= 3 }
                    )
                }
            }
        }
    }

    // ================= Modul 1: Ekstraktor Teks Alamat =================

    /** Dipanggil setiap perubahan teks di area paste — regex ringan sehingga aman dijalankan live. */
    fun onAddressTextChanged(newText: String) {
        val extracted = if (newText.isBlank()) null else extractOrderTextUseCase(newText)
        _uiState.update {
            it.copy(addressInput = AddressExtractionState(rawText = newText, extracted = extracted))
        }
    }

    // ================= Modul 3: Kalkulator HPP & Stok =================

    fun onHppProductNameChanged(value: String) = updateHppField { it.copy(productName = value) }

    fun onHppCategoryChanged(category: BusinessCategory) = updateHppField { it.copy(category = category) }

    fun onHppRawMaterialCostChanged(value: String) =
        updateHppField { it.copy(rawMaterialCost = value.filterAsDecimal()) }

    fun onHppMonthlyOperationalCostChanged(value: String) =
        updateHppField { it.copy(monthlyOperationalCost = value.filterAsDecimal()) }

    fun onHppEstimatedProductionChanged(value: String) =
        updateHppField { it.copy(estimatedMonthlyProduction = value.filterAsInteger()) }

    fun onHppMarginChanged(value: String) =
        updateHppField { it.copy(marginPercentage = value.filterAsDecimal()) }

    fun onHppInitialStockChanged(value: String) =
        updateHppField { it.copy(initialStock = value.filterAsInteger()) }

    private fun updateHppField(transform: (HppCalculatorState) -> HppCalculatorState) {
        _uiState.update { current ->
            val updatedFields = transform(current.hppCalculator)
            current.copy(hppCalculator = recalculateHpp(updatedFields))
        }
    }

    private fun recalculateHpp(state: HppCalculatorState): HppCalculatorState {
        val rawMaterial = state.rawMaterialCost.toDoubleOrNull()
        val operational = state.monthlyOperationalCost.toDoubleOrNull()
        val production = state.estimatedMonthlyProduction.toIntOrNull()
        val margin = state.marginPercentage.toDoubleOrNull()

        // Selagi form belum lengkap, jangan tampilkan hasil ataupun pesan error —
        // biarkan pengguna mengetik tanpa gangguan validasi prematur.
        if (rawMaterial == null || operational == null || production == null || margin == null) {
            return state.copy(result = null, errorMessage = null)
        }

        val result = calculateHppUseCase(
            HppInput(
                rawMaterialCostPerUnit = rawMaterial,
                monthlyOperationalCost = operational,
                estimatedMonthlyProduction = production,
                marginPercentage = margin
            )
        )

        val errorMessage = when {
            result != null -> null
            margin >= 100 -> "Margin keuntungan harus di bawah 100%"
            production <= 0 -> "Estimasi produksi per bulan harus lebih dari 0"
            else -> "Periksa kembali angka yang dimasukkan"
        }

        return state.copy(result = result, errorMessage = errorMessage)
    }

    /** Simpan hasil kalkulasi HPP sebagai produk baru + stok awal ke Room DB via ProductRepository. */
    fun saveProduct() {
        val state = _uiState.value.hppCalculator

        if (state.productName.isBlank()) {
            updateHppField { it.copy(errorMessage = "Nama produk wajib diisi") }
            return
        }
        val result = state.result
        if (result == null) {
            updateHppField { it.copy(errorMessage = "Lengkapi semua kolom perhitungan HPP terlebih dahulu") }
            return
        }

        val initialStock = state.initialStock.toIntOrNull() ?: 0
        val productName = state.productName.trim()

        viewModelScope.launch {
            productRepository.saveProduct(
                Product(
                    id = 0,
                    name = productName,
                    sellPrice = result.idealSellPrice,
                    hppPrice = result.hppPerUnit,
                    stockQuantity = initialStock,
                    category = state.category,
                    imageUri = null,
                    isPublishedToCatalog = false
                )
            )
            _uiState.update {
                it.copy(
                    hppCalculator = HppCalculatorState(),
                    saveMessage = "Produk \"$productName\" berhasil disimpan ke stok"
                )
            }
        }
    }

    fun clearSaveMessage() {
        _uiState.update { it.copy(saveMessage = null) }
    }
}

private fun String.filterAsInteger(): String = filter { it.isDigit() }

private fun String.filterAsDecimal(): String {
    var dotUsed = false
    return filter { ch ->
        when {
            ch.isDigit() -> true
            ch == '.' && !dotUsed -> {
                dotUsed = true
                true
            }
            else -> false
        }
    }
}
