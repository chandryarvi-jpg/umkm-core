package com.umkmcore.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.umkmcore.app.ui.navigation.UmkmNavHost
import com.umkmcore.app.ui.theme.UmkmCoreTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-Activity architecture. Semua layar (Dashboard, Modul 1-4) adalah
 * Composable yang dinavigasikan lewat NavHost — bukan Activity terpisah.
 * Ini penting untuk performa & memory footprint rendah di device low-end.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UmkmCoreTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    UmkmNavHost(navController = navController)
                }
            }
        }
    }
}
