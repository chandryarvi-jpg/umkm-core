package com.umkmcore.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Entry point Hilt untuk seluruh graph dependency aplikasi.
 * Semua @Module yang di-@InstallIn(SingletonComponent::class) akan hidup
 * selama proses aplikasi berjalan (cocok untuk Room DB & Retrofit client).
 */
@HiltAndroidApp
class UmkmCoreApplication : Application()
