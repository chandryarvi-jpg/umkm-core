package com.umkmcore.app.domain.repository

import com.umkmcore.app.domain.model.ExtractedOrderText
import com.umkmcore.app.domain.model.Order
import kotlinx.coroutines.flow.Flow

interface OrderRepository {
    fun observeOrders(): Flow<List<Order>>

    /** Menyimpan order dari hasil ekstraksi Modul 1, sekaligus upsert Customer terkait. */
    suspend fun createOrderFromExtractedText(
        extracted: ExtractedOrderText,
        shippingCost: Double?,
        totalAmount: Double,
        relatedProductId: Long?,
        quantity: Int
    ): Long
}
