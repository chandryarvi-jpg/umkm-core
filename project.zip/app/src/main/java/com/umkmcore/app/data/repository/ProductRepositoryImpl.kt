package com.umkmcore.app.data.repository

import com.umkmcore.app.data.local.dao.ProductDao
import com.umkmcore.app.data.local.entity.ProductEntity
import com.umkmcore.app.domain.model.BusinessCategory
import com.umkmcore.app.domain.model.Product
import com.umkmcore.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class ProductRepositoryImpl @Inject constructor(
    private val productDao: ProductDao
) : ProductRepository {

    override fun observeProducts(): Flow<List<Product>> =
        productDao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getProduct(id: Long): Product? =
        productDao.getById(id)?.toDomain()

    override suspend fun saveProduct(product: Product): Long =
        productDao.upsert(product.toEntity())

    override suspend fun decrementStock(productId: Long, quantity: Int) =
        productDao.decrementStock(productId, quantity)

    override suspend fun getCatalogProducts(): List<Product> =
        productDao.getCatalogProducts().map { it.toDomain() }
}

private fun ProductEntity.toDomain() = Product(
    id = id,
    name = name,
    sellPrice = sellPrice,
    hppPrice = hppPrice,
    stockQuantity = stockQuantity,
    category = runCatching { BusinessCategory.valueOf(category) }.getOrDefault(BusinessCategory.FNB),
    imageUri = imageUri,
    isPublishedToCatalog = isPublishedToCatalog
)

private fun Product.toEntity() = ProductEntity(
    id = id,
    name = name,
    sellPrice = sellPrice,
    hppPrice = hppPrice,
    stockQuantity = stockQuantity,
    category = category.name,
    imageUri = imageUri,
    isPublishedToCatalog = isPublishedToCatalog
)
