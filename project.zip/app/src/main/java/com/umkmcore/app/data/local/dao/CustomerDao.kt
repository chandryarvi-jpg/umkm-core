package com.umkmcore.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.umkmcore.app.data.local.entity.CustomerEntity

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE phoneNumber = :phone LIMIT 1")
    suspend fun findByPhone(phone: String): CustomerEntity?

    // Upsert berbasis nomor HP unik — mencegah duplikasi pelanggan dari hasil
    // ekstraktor teks Modul 1 setiap kali order baru masuk.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(customer: CustomerEntity): Long
}
