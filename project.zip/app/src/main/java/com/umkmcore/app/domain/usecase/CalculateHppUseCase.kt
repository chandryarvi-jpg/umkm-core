package com.umkmcore.app.domain.usecase

import javax.inject.Inject
import kotlin.math.ceil

/** Input mentah dari form Kalkulator HPP. */
data class HppInput(
    val rawMaterialCostPerUnit: Double,
    val monthlyOperationalCost: Double,
    val estimatedMonthlyProduction: Int,
    val marginPercentage: Double
)

/** Hasil kalkulasi siap tampil di UI. */
data class HppResult(
    val operationalCostPerUnit: Double,
    val hppPerUnit: Double,
    val idealSellPrice: Double,
    val profitPerUnit: Double,
    val bepUnits: Int
)

/**
 * Formula: Bahan Baku + (Biaya Operasional / Estimasi Produksi) = HPP per unit.
 * Harga Jual Ideal dihitung dari margin sebagai persentase HARGA JUAL (bukan markup dari HPP),
 * konsisten dengan definisi `Product.marginPercentage` di domain model:
 *
 *     Harga Jual = HPP / (1 - margin/100)
 *
 * BEP (unit/bulan) = Biaya Operasional Tetap / (Harga Jual - Biaya Bahan Baku per unit),
 * yaitu Biaya Tetap dibagi Margin Kontribusi per unit.
 */
class CalculateHppUseCase @Inject constructor() {

    operator fun invoke(input: HppInput): HppResult? {
        if (input.estimatedMonthlyProduction <= 0) return null
        if (input.marginPercentage < 0 || input.marginPercentage >= 100) return null
        if (input.rawMaterialCostPerUnit < 0 || input.monthlyOperationalCost < 0) return null

        val operationalCostPerUnit = input.monthlyOperationalCost / input.estimatedMonthlyProduction
        val hppPerUnit = input.rawMaterialCostPerUnit + operationalCostPerUnit
        val idealSellPrice = hppPerUnit / (1 - input.marginPercentage / 100)
        val profitPerUnit = idealSellPrice - hppPerUnit

        val contributionMargin = idealSellPrice - input.rawMaterialCostPerUnit
        val bepUnits = if (contributionMargin > 0.0) {
            ceil(input.monthlyOperationalCost / contributionMargin).toInt()
        } else {
            0
        }

        return HppResult(
            operationalCostPerUnit = operationalCostPerUnit,
            hppPerUnit = hppPerUnit,
            idealSellPrice = idealSellPrice,
            profitPerUnit = profitPerUnit,
            bepUnits = bepUnits
        )
    }
}
