package com.umkmcore.app.domain.model

data class Order(
    val id: Long,
    val customer: Customer,
    val extractedAddress: String,
    val courierName: String?,
    val shippingCost: Double?,
    val totalAmount: Double,
    val status: OrderStatus
)

enum class OrderStatus { PENDING_PRINT, PRINTED, DONE }

/**
 * Hasil parsing regex mentah dari Modul 1, sebelum disimpan sebagai Order.
 * Dipisah agar UI bisa menampilkan/mengoreksi hasil deteksi sebelum disimpan.
 */
data class ExtractedOrderText(
    val recipientName: String?,
    val phoneNumber: String?,
    val fullAddress: String?,
    val courierName: String?,
    val rawText: String
) {
    val isComplete: Boolean
        get() = !recipientName.isNullOrBlank() && !phoneNumber.isNullOrBlank() && !fullAddress.isNullOrBlank()
}
