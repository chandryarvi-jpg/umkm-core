package com.umkmcore.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * Tabel Orders — hasil ekstraksi teks chat WA/IG di Modul 1, dan sumber
 * pengurangan stok otomatis (lihat ProductDao.decrementStock).
 */
@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long?,
    val rawChatText: String,       // teks mentah asli hasil copy-paste, disimpan untuk audit
    val extractedAddress: String,
    val courierName: String?,      // Ekspedisi/Kurir hasil deteksi regex
    val shippingCost: Double?,     // hasil Cek Ongkir dari Modul 2
    val totalAmount: Double,
    val status: String = "PENDING_PRINT", // PENDING_PRINT, PRINTED, DONE
    val createdAt: Long = System.currentTimeMillis()
)
