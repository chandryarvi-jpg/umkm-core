package com.umkmcore.app.core.di

import com.umkmcore.app.data.repository.ProductRepositoryImpl
import com.umkmcore.app.domain.repository.ProductRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Menjembatani domain (interface) dengan data (implementasi) tanpa membuat
 * domain layer bergantung pada Room sama sekali — inti dari Clean/MVVM modular.
 *
 * TODO tahap berikutnya: tambahkan @Binds untuk OrderRepositoryImpl & ContentRepositoryImpl
 * begitu diimplementasikan pada Langkah 3 (Modul 1 & seterusnya).
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindProductRepository(impl: ProductRepositoryImpl): ProductRepository
}
