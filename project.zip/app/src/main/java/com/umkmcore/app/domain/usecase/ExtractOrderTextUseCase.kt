package com.umkmcore.app.domain.usecase

import com.umkmcore.app.core.util.RegexExtractor
import com.umkmcore.app.domain.model.ExtractedOrderText
import javax.inject.Inject

class ExtractOrderTextUseCase @Inject constructor() {
    operator fun invoke(rawText: String): ExtractedOrderText = RegexExtractor.extract(rawText)
}
