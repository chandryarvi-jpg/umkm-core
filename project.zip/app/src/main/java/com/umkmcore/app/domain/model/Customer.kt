package com.umkmcore.app.domain.model

data class Customer(
    val id: Long,
    val name: String,
    val phoneNumber: String,
    val fullAddress: String
)
