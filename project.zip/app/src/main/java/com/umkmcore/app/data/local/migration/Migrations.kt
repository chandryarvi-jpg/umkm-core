package com.umkmcore.app.data.local.migration

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Semua migrasi Room terdaftar untuk UmkmCoreDatabase. Menggantikan
 * `fallbackToDestructiveMigration()` yang berbahaya untuk produksi karena
 * menghapus seluruh data stok UMKM begitu skema database berubah.
 *
 * MIGRATION_1_2 di bawah sengaja KOSONG (no-op) karena belum ada perubahan skema
 * — ini adalah BOILERPLATE yang jadi contoh pola wajib diikuti untuk migrasi
 * berikutnya. Jangan menaikkan `version` di UmkmCoreDatabase tanpa menambah
 * Migration baru di sini, atau aplikasi akan crash `IllegalStateException` saat
 * pengguna update dari versi database lama.
 *
 * Contoh nyata seandainya nanti menambah kolom baru (mis. `notes` di tabel products):
 *
 * ```
 * val MIGRATION_2_3 = object : Migration(2, 3) {
 *     override fun migrate(db: SupportSQLiteDatabase) {
 *         db.execSQL("ALTER TABLE products ADD COLUMN notes TEXT DEFAULT NULL")
 *     }
 * }
 * ```
 *
 * Atau menambah tabel baru:
 * ```
 * db.execSQL(
 *     """
 *     CREATE TABLE IF NOT EXISTS `promotions` (
 *         `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
 *         `productId` INTEGER NOT NULL,
 *         `discountPercent` REAL NOT NULL
 *     )
 *     """.trimIndent()
 * )
 * ```
 */
val MIGRATION_1_2 = object : Migration(startVersion = 1, endVersion = 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        // Tidak ada perubahan skema pada versi ini — migrasi kosong yang aman.
        // Body ini WAJIB berisi ALTER/CREATE TABLE yang sesuai begitu ProductEntity,
        // OrderEntity, CustomerEntity, atau ContentTemplateEntity benar-benar diubah.
    }
}

/** Daftarkan setiap migrasi baru di sini, lalu pasang lewat DatabaseModule.addMigrations(*ALL_MIGRATIONS). */
val ALL_MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_1_2)
