package com.umkmcore.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Tabel Customers — dinormalisasi dari hasil ekstraktor teks Modul 1
 * ([Nama Penerima], [Nomor HP], [Alamat Lengkap]).
 */
@Entity(
    tableName = "customers",
    indices = [Index(value = ["phoneNumber"], unique = true)]
)
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val fullAddress: String
)
