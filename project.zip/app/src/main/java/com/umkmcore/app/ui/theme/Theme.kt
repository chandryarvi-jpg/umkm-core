package com.umkmcore.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = UmkmGreenPrimary,
    secondary = UmkmOrangeAccent,
    surface = UmkmSurfaceLight,
    error = UmkmError
)

private val DarkColors = darkColorScheme(
    primary = UmkmGreenPrimaryDark,
    secondary = UmkmOrangeAccent,
    surface = UmkmSurfaceDark,
    error = UmkmError
)

// Sudut lebih membulat dari default Material3 — kesan hangat/ramah untuk UMKM,
// bukan kaku ala aplikasi korporat.
private val UmkmShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

/**
 * Sengaja TIDAK memakai Dynamic Color (Material You) supaya tampilan konsisten
 * di semua device merchant, termasuk Android versi lama tanpa dynamic color API.
 */
@Composable
fun UmkmCoreTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = UmkmTypography,
        shapes = UmkmShapes,
        content = content
    )
}
