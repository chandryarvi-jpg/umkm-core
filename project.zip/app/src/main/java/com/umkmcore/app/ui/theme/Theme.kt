package com.umkmcore.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = UmkmGreenPrimary,
    secondary = UmkmOrangeAccent,
    surface = UmkmSurfaceLight,
    error = UmkmError
)

private val DarkColors = darkColorScheme(
    primary = UmkmGreenPrimaryDark,
    secondary = UmkmOrangeAccent,
    surface = UmkmSurfaceDark,
    error = UmkmError
)

/**
 * Sengaja TIDAK memakai Dynamic Color (Material You) supaya tampilan konsisten
 * di semua device merchant, termasuk Android versi lama tanpa dynamic color API.
 */
@Composable
fun UmkmCoreTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = UmkmTypography,
        content = content
    )
}
