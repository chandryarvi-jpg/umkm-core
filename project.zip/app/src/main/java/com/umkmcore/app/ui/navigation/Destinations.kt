package com.umkmcore.app.ui.navigation

/** Satu sumber kebenaran untuk semua rute — hindari hardcode string route di banyak tempat. */
sealed class Destination(val route: String) {
    // Modul 1 (Cetak Resi) & Modul 3 (Kalkulator HPP) sudah menyatu di dalam Dashboard,
    // sehingga tidak lagi punya rute navigasi terpisah.
    data object Dashboard : Destination("dashboard")
    data object SalesKeyboard : Destination("module2_keyboard") // Modul 2 (entry/setting screen)
    data object CatalogContent : Destination("module4_katalog") // Modul 4
}
