package com.umkmcore.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.umkmcore.app.data.local.dao.ContentTemplateDao
import com.umkmcore.app.data.local.dao.CustomerDao
import com.umkmcore.app.data.local.dao.OrderDao
import com.umkmcore.app.data.local.dao.ProductDao
import com.umkmcore.app.data.local.entity.ContentTemplateEntity
import com.umkmcore.app.data.local.entity.CustomerEntity
import com.umkmcore.app.data.local.entity.OrderEntity
import com.umkmcore.app.data.local.entity.ProductEntity

/**
 * Single source of truth offline-first. Sinkronisasi ke Google Sheets API / Supabase
 * (opsional) akan dilakukan sebagai lapisan terpisah di atas repository, bukan
 * menggantikan Room — sehingga aplikasi tetap 100% fungsional tanpa internet.
 *
 * PENTING: setiap kali `version` di sini dinaikkan, WAJIB tambahkan objek Migration
 * baru di [com.umkmcore.app.data.local.migration.Migrations] dan daftarkan lewat
 * `.addMigrations(...)` di DatabaseModule. JANGAN gunakan fallbackToDestructiveMigration()
 * di build produksi — itu akan menghapus seluruh data stok UMKM saat versi berubah.
 */
@Database(
    entities = [
        ProductEntity::class,
        OrderEntity::class,
        CustomerEntity::class,
        ContentTemplateEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class UmkmCoreDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun orderDao(): OrderDao
    abstract fun customerDao(): CustomerDao
    abstract fun contentTemplateDao(): ContentTemplateDao

    companion object {
        const val DATABASE_NAME = "umkm_core.db"
    }
}
