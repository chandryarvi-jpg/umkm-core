package com.umkmcore.app.domain.model

data class SalesMacro(
    val id: Long,
    val title: String,
    val body: String
)

data class ContentIdea(
    val id: Long,
    val dayNumber: Int,
    val category: BusinessCategory,
    val title: String,
    val caption: String
)
