package com.umkmcore.app.ui.module2_keyboard

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/** Placeholder — layar setting/aktivasi IME Custom Keyboard. */
@Composable
fun SalesKeyboardScreenPlaceholder() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Modul 2: Keyboard Jualan — segera hadir")
    }
}
