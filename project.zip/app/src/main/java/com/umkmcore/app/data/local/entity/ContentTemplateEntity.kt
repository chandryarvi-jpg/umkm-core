package com.umkmcore.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Tabel ContentTemplates — dua peran sekaligus:
 * 1) Template chat balasan cepat untuk Custom Sales Keyboard (Modul 2).
 * 2) Ide konten harian (30 hari) per kategori bisnis untuk Modul 4.
 */
@Entity(tableName = "content_templates")
data class ContentTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,       // "SALES_MACRO" (Modul 2) atau "CONTENT_IDEA" (Modul 4)
    val category: String,   // F&B, Fashion, Jasa — atau "GENERAL" untuk macro chat
    val dayNumber: Int? = null, // hanya dipakai untuk CONTENT_IDEA (hari ke-1..30)
    val title: String,
    val body: String        // isi macro chat atau caption siap pakai
)
