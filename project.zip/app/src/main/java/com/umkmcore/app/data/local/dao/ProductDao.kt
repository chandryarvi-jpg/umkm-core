package com.umkmcore.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.umkmcore.app.data.local.entity.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getById(id: Long): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ProductEntity): Long

    @Update
    suspend fun update(product: ProductEntity)

    // Dipanggil otomatis setiap tombol "Cek Resi/Format Order" (Modul 1 & 2) dieksekusi,
    // sesuai spesifikasi Stok Mikro di Modul 3.
    @Query("UPDATE products SET stockQuantity = stockQuantity - :qty WHERE id = :productId")
    suspend fun decrementStock(productId: Long, qty: Int)

    @Query("SELECT * FROM products WHERE isPublishedToCatalog = 1")
    suspend fun getCatalogProducts(): List<ProductEntity>
}
