package com.umkmcore.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Tabel Products — dipakai oleh Modul 3 (HPP & Stok) dan Modul 4 (Katalog).
 */
@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sellPrice: Double,
    val hppPrice: Double, // Harga Pokok Produksi hasil kalkulasi Modul 3
    val stockQuantity: Int,
    val category: String, // F&B, Fashion, Jasa — dipakai juga oleh Modul 4 untuk ide konten
    val imageUri: String? = null,
    val isPublishedToCatalog: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
