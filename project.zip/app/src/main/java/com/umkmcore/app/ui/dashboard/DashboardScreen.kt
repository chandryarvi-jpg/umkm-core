package com.umkmcore.app.ui.dashboard

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.umkmcore.app.domain.model.BusinessCategory
import com.umkmcore.app.domain.model.ExtractedOrderText
import com.umkmcore.app.domain.model.Product
import com.umkmcore.app.domain.model.displayLabel
import com.umkmcore.app.ui.module1_resi.BluetoothPrinterHelper
import com.umkmcore.app.ui.module1_resi.ThermalLabelPreview
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Dashboard tunggal yang menyatukan Modul 1 (Ekstraktor Alamat + Cetak Resi),
 * Modul 3 (Kalkulator HPP + Stok), dan daftar stok — sesuai spesifikasi
 * "Dashboard minimalis" yang mudah dipakai merchant tanpa training tambahan.
 *
 * onOpenSalesKeyboard/onOpenCatalogContent bersifat opsional (default no-op)
 * agar composable ini tetap bisa dipakai berdiri sendiri, namun tersambung ke
 * NavHost saat dua modul tersebut sudah tersedia.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onOpenSalesKeyboard: () -> Unit = {},
    onOpenCatalogContent: () -> Unit = {},
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(uiState.saveMessage) {
        uiState.saveMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearSaveMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("UMKM-Core") },
                actions = {
                    TextButton(onClick = onOpenSalesKeyboard) { Text("Keyboard") }
                    TextButton(onClick = onOpenCatalogContent) { Text("Katalog") }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            SummaryHeader(uiState = uiState)

            AddressExtractionSection(
                rawText = uiState.addressInput.rawText,
                extracted = uiState.addressInput.extracted,
                onRawTextChanged = viewModel::onAddressTextChanged,
                snackbarHostState = snackbarHostState,
                coroutineScope = coroutineScope
            )

            HppCalculatorSection(
                state = uiState.hppCalculator,
                onProductNameChanged = viewModel::onHppProductNameChanged,
                onCategoryChanged = viewModel::onHppCategoryChanged,
                onRawMaterialCostChanged = viewModel::onHppRawMaterialCostChanged,
                onMonthlyOperationalCostChanged = viewModel::onHppMonthlyOperationalCostChanged,
                onEstimatedProductionChanged = viewModel::onHppEstimatedProductionChanged,
                onMarginChanged = viewModel::onHppMarginChanged,
                onInitialStockChanged = viewModel::onHppInitialStockChanged,
                onSaveClicked = viewModel::saveProduct
            )

            StockListSection(products = uiState.products)
        }
    }
}

@Composable
private fun SummaryHeader(uiState: DashboardUiState) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Total produk: ${uiState.products.size}", style = MaterialTheme.typography.bodyLarge)
            if (uiState.lowStockProducts.isNotEmpty()) {
                Text(
                    text = "⚠️ ${uiState.lowStockProducts.size} produk stok menipis (≤3 unit)",
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

// ================= Modul 1: Ekstraktor Alamat & Cetak Resi =================

@Composable
private fun AddressExtractionSection(
    rawText: String,
    extracted: ExtractedOrderText?,
    onRawTextChanged: (String) -> Unit,
    snackbarHostState: SnackbarHostState,
    coroutineScope: CoroutineScope
) {
    val context = LocalContext.current
    val storeName = "Toko Saya"
    var showPrinterMenu by remember { mutableStateOf(false) }
    var pairedPrinters by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }

    val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pairedPrinters = BluetoothPrinterHelper.getPairedPrinters(context)
            showPrinterMenu = true
        } else {
            coroutineScope.launch { snackbarHostState.showSnackbar("Izin Bluetooth ditolak") }
        }
    }

    fun openPrinterPicker() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            bluetoothPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            pairedPrinters = BluetoothPrinterHelper.getPairedPrinters(context)
            showPrinterMenu = true
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Modul 1 — Tempel Chat Pesanan", style = MaterialTheme.typography.titleLarge)
            Text(
                text = "Salin chat pesanan dari WhatsApp/Instagram, lalu tempel di sini. " +
                    "Nama, No. HP, Alamat, dan Kurir terdeteksi otomatis.",
                style = MaterialTheme.typography.bodyLarge
            )

            OutlinedTextField(
                value = rawText,
                onValueChange = onRawTextChanged,
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                label = { Text("Teks chat pesanan") },
                placeholder = {
                    Text("Contoh:\nNama: Budi Santoso\nNo HP: 081234567890\nAlamat: Jl. Melati No 5, RT 02/RW 03\nKurir: JNE")
                },
                minLines = 5
            )

            if (extracted != null && rawText.isNotBlank()) {
                HorizontalDivider()
                ExtractedFieldRow("Nama", extracted.recipientName ?: "Tidak terdeteksi")
                ExtractedFieldRow("No. HP", extracted.phoneNumber ?: "Tidak terdeteksi")
                ExtractedFieldRow("Alamat", extracted.fullAddress ?: "Tidak terdeteksi")
                ExtractedFieldRow("Kurir", extracted.courierName ?: "Tidak terdeteksi")

                Spacer(modifier = Modifier.height(4.dp))
                Text("Pratinjau Label 58mm", style = MaterialTheme.typography.labelLarge)
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ThermalLabelPreview(storeName = storeName, extracted = extracted)
                }

                Spacer(modifier = Modifier.height(4.dp))
                Box(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { openPrinterPicker() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = extracted.isComplete
                    ) {
                        Text("🖨  Cetak ke Printer Thermal")
                    }
                    DropdownMenu(expanded = showPrinterMenu, onDismissRequest = { showPrinterMenu = false }) {
                        if (pairedPrinters.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("Tidak ada printer terpasang. Pasangkan dulu lewat Pengaturan Bluetooth.") },
                                onClick = { showPrinterMenu = false }
                            )
                        } else {
                            pairedPrinters.forEach { device ->
                                DropdownMenuItem(
                                    text = { Text(runCatching { device.name }.getOrNull() ?: device.address) },
                                    onClick = {
                                        showPrinterMenu = false
                                        coroutineScope.launch {
                                            val result = BluetoothPrinterHelper.printLabel(
                                                context = context,
                                                device = device,
                                                storeName = storeName,
                                                extracted = extracted
                                            )
                                            val message = when (result) {
                                                is BluetoothPrinterHelper.PrintResult.Success ->
                                                    "Label berhasil dikirim ke printer"
                                                is BluetoothPrinterHelper.PrintResult.Failure ->
                                                    "Gagal cetak: ${result.reason}"
                                            }
                                            snackbarHostState.showSnackbar(message)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExtractedFieldRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(text = "$label:", fontWeight = FontWeight.Bold, modifier = Modifier.width(90.dp))
        Text(text = value)
    }
}

// ================= Modul 3: Kalkulator HPP & Stok =================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HppCalculatorSection(
    state: HppCalculatorState,
    onProductNameChanged: (String) -> Unit,
    onCategoryChanged: (BusinessCategory) -> Unit,
    onRawMaterialCostChanged: (String) -> Unit,
    onMonthlyOperationalCostChanged: (String) -> Unit,
    onEstimatedProductionChanged: (String) -> Unit,
    onMarginChanged: (String) -> Unit,
    onInitialStockChanged: (String) -> Unit,
    onSaveClicked: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Modul 3 — Kalkulator HPP & Stok", style = MaterialTheme.typography.titleLarge)

            OutlinedTextField(
                value = state.productName,
                onValueChange = onProductNameChanged,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Nama Produk") },
                singleLine = true
            )

            var categoryMenuExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = categoryMenuExpanded,
                onExpandedChange = { categoryMenuExpanded = it }
            ) {
                OutlinedTextField(
                    value = state.category.displayLabel(),
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Kategori Bisnis") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryMenuExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                )
                ExposedDropdownMenu(
                    expanded = categoryMenuExpanded,
                    onDismissRequest = { categoryMenuExpanded = false }
                ) {
                    BusinessCategory.entries.forEach { category ->
                        DropdownMenuItem(
                            text = { Text(category.displayLabel()) },
                            onClick = {
                                onCategoryChanged(category)
                                categoryMenuExpanded = false
                            }
                        )
                    }
                }
            }
            OutlinedTextField(
                value = state.rawMaterialCost,
                onValueChange = onRawMaterialCostChanged,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Biaya Bahan Baku per Unit (Rp)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            OutlinedTextField(
                value = state.monthlyOperationalCost,
                onValueChange = onMonthlyOperationalCostChanged,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Biaya Operasional per Bulan (Rp)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            OutlinedTextField(
                value = state.estimatedMonthlyProduction,
                onValueChange = onEstimatedProductionChanged,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Estimasi Produksi per Bulan (unit)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            OutlinedTextField(
                value = state.marginPercentage,
                onValueChange = onMarginChanged,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Margin Keuntungan (%)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            OutlinedTextField(
                value = state.initialStock,
                onValueChange = onInitialStockChanged,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Stok Awal (unit)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )

            state.errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelLarge)
            }

            state.result?.let { result ->
                HorizontalDivider()
                ResultRow("Biaya Operasional/unit", formatRupiah(result.operationalCostPerUnit))
                ResultRow("HPP per Unit", formatRupiah(result.hppPerUnit))
                ResultRow("Harga Jual Ideal", formatRupiah(result.idealSellPrice))
                ResultRow("Keuntungan per Unit", formatRupiah(result.profitPerUnit))
                ResultRow("Break-Even Point (BEP)", "${result.bepUnits} unit/bulan")
            }

            Button(
                onClick = onSaveClicked,
                modifier = Modifier.fillMaxWidth(),
                enabled = state.result != null && state.productName.isNotBlank()
            ) {
                Text("💾  Simpan ke Stok")
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

// ================= Daftar Stok Barang =================

@Composable
private fun StockListSection(products: List<Product>) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Daftar Stok Barang", style = MaterialTheme.typography.titleLarge)
            if (products.isEmpty()) {
                Text("Belum ada produk. Simpan produk pertamamu lewat Kalkulator HPP di atas.")
            } else {
                products.forEach { product ->
                    ProductRow(product)
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun ProductRow(product: Product) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(product.name, fontWeight = FontWeight.Bold)
            Text(formatRupiah(product.sellPrice), style = MaterialTheme.typography.bodyLarge)
        }
        Text(
            text = "Stok: ${product.stockQuantity}",
            color = if (product.stockQuantity <= 3) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
    }
}

private fun formatRupiah(value: Double): String {
    val rounded = value.toLong().coerceAtLeast(0)
    val grouped = rounded.toString().reversed().chunked(3).joinToString(".").reversed()
    return "Rp $grouped"
}
