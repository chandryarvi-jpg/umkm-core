package com.umkmcore.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.umkmcore.app.data.local.entity.ContentTemplateEntity

@Dao
interface ContentTemplateDao {
    @Query("SELECT * FROM content_templates WHERE type = 'SALES_MACRO'")
    suspend fun getSalesMacros(): List<ContentTemplateEntity>

    @Query("SELECT * FROM content_templates WHERE type = 'CONTENT_IDEA' AND category = :category ORDER BY dayNumber ASC")
    suspend fun getContentIdeasByCategory(category: String): List<ContentTemplateEntity>

    @Insert
    suspend fun insertAll(templates: List<ContentTemplateEntity>)
}
