package com.umkmcore.app.ui.module1_resi

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.umkmcore.app.domain.model.ExtractedOrderText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID

/**
 * Helper cetak label ke printer thermal Bluetooth (58mm/80mm) lewat protokol
 * Classic Bluetooth SPP + perintah ESC/POS mentah. Pendekatan ini dipilih karena
 * kompatibel dengan mayoritas printer thermal murah yang beredar di pasar UMKM
 * tanpa perlu SDK vendor khusus atau driver tambahan.
 */
object BluetoothPrinterHelper {

    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    sealed class PrintResult {
        data object Success : PrintResult()
        data class Failure(val reason: String) : PrintResult()
    }

    /** Android 12+ mewajibkan izin runtime BLUETOOTH_CONNECT; di bawahnya cukup izin manifest. */
    fun hasBluetoothPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedPrinters(context: Context): List<BluetoothDevice> {
        if (!hasBluetoothPermission(context)) return emptyList()
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        if (!adapter.isEnabled) return emptyList()
        return adapter.bondedDevices?.toList().orEmpty()
    }

    @SuppressLint("MissingPermission")
    suspend fun printLabel(
        context: Context,
        device: BluetoothDevice,
        storeName: String,
        extracted: ExtractedOrderText
    ): PrintResult = withContext(Dispatchers.IO) {
        if (!hasBluetoothPermission(context)) {
            return@withContext PrintResult.Failure("Izin Bluetooth belum diberikan")
        }

        var socket: BluetoothSocket? = null
        try {
            BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()

            val payload = buildEscPosPayload(storeName, extracted)
            socket.outputStream.write(payload)
            socket.outputStream.flush()

            PrintResult.Success
        } catch (e: IOException) {
            PrintResult.Failure(e.message ?: "Gagal terhubung ke printer")
        } finally {
            try {
                socket?.close()
            } catch (_: IOException) {
                // Soket sudah tertutup/terputus — aman untuk diabaikan.
            }
        }
    }

    /**
     * Menyusun byte perintah ESC/POS untuk kertas 58mm (32 kolom karakter font normal).
     * Referensi command set: ESC @ (init/reset), ESC a (alignment), ESC E (bold),
     * GS V (full cut).
     */
    private fun buildEscPosPayload(storeName: String, extracted: ExtractedOrderText): ByteArray {
        val out = ByteArrayOutputStream()

        fun cmd(vararg bytes: Int) = out.write(bytes.map { it.toByte() }.toByteArray())
        fun raw(text: String) = out.write(text.toByteArray(Charsets.UTF_8))
        fun line(text: String = "") = raw("$text\n")

        cmd(0x1B, 0x40) // ESC @ : initialize printer, hapus buffer & format sebelumnya

        cmd(0x1B, 0x61, 1) // ESC a 1 : rata tengah
        cmd(0x1B, 0x45, 1) // ESC E 1 : bold ON
        line(storeName.ifBlank { "TOKO ANDA" }.uppercase())
        cmd(0x1B, 0x45, 0) // bold OFF
        line("--------------------------------")

        cmd(0x1B, 0x61, 0) // rata kiri
        line("Penerima : ${extracted.recipientName ?: "-"}")
        line("No. HP   : ${extracted.phoneNumber ?: "-"}")
        line("Kurir    : ${extracted.courierName ?: "-"}")
        line()
        line("Alamat:")
        line(extracted.fullAddress ?: "-")
        line("--------------------------------")

        cmd(0x1B, 0x61, 1)
        line("Dicetak via UMKM-Core")
        line()
        line()
        line()

        cmd(0x1D, 0x56, 0x00) // GS V 0 : potong kertas penuh

        return out.toByteArray()
    }
}
