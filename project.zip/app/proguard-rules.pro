# Aturan ProGuard/R8 khusus UMKM-Core.
# Room, Hilt, dan Retrofit sudah menyertakan consumer-rules bawaan masing-masing,
# jadi file ini sengaja dibiarkan minimal di tahap fondasi.

# Jaga model data (untuk serialization JSON API Ongkir) agar tidak di-obfuscate.
-keep class com.umkmcore.app.data.remote.dto.** { *; }
-keep class com.umkmcore.app.domain.model.** { *; }
